lokasi_kerja <- "D:/TB Data Mining"
setwd(lokasi_kerja)
getwd()

install.packages("cluster")
install.packages("fpc")
install.packages("ggplot2")
install.packages("rJava")

library("cluster")
library("fpc")
library("ggplot2")
library("rJava")

starbucks <- read.csv("starbucks.csv", sep = ",")

starbucks.f = starbucks
starbucks.f$Menu <- NULL
View (starbucks.f)

starbucks.stand <- scale(starbucks.f[-1])

View(starbucks.stand)
head(starbucks.stand)
starbucks.stand$Menu

set.seed (8953)
hasil <- kmeans(starbucks.stand, 3)
hasil

hasil$cluster

hasil$size
hasil$centers

table(starbucks$Menu, hasil$cluster)

plot(starbucks.stand, col = hasil$cluster)

points(hasil$centers, col = 2:6, pch = 8, cex = 2)

clusplot(starbucks.stand, hasil$cluster, color = T, shade = T, table = 2, lines = 0)


set.seed(1234)

ind <- sample(2, nrow(starbucks), replace=TRUE, prob=c(0.7, 0.3))
data.training <- starbucks[ind==0.7,]
data.test <- starbucks[ind==0.3,]


